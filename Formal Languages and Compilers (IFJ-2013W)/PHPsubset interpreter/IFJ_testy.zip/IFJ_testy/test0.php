<?php
$x=put_string("Hello, World!");
 ?>
