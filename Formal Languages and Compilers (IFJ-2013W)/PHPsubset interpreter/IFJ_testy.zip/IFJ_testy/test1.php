 <?php

 //scitani a nasobeni

      function abc($a, $b, $c) {
            return $a*$b+$c;
      }
      $x=1.5;
      $y=2;
      $z=3;
      $vysl = "Vysledek = " . abc($x,$y,$z) . "\n";
      $aa = put_string($vysl);
 ?>
