<?php

//faktorial rekurzivne

$z = put_string("Zadejte cislo pro vypocet faktorialu\n ");
$a = get_string();
$a = intval($a);



//funkce pro vypocet faktorialu

function factorial($n)
{
if ($n < 2)
{
$result = 1;
}
else
{
$dec_n = $n - 1;
$temp_result = factorial($dec_n);
$result = $n * $temp_result;
}
return $result;
}

// konec funkce pro vypocet faktorialu

if ($a < 0)
{
$message = "Cislo <0\n";
}
else
{
$vysl = factorial($a);
$message = "Vysledek je: " . $vysl . "\n";
}
$x = put_string($message);

?>
