 <?php

//faktorial cisla 5 iterativne

$a = 5;
if ($a < 0)
{
$x = put_string("Cislo <0\n");
}
else
{
$vysl = 1;
while ($a > 0)
{
$vysl = $vysl * $a;
$a = $a - 1;
}
$x = put_string("Vysledek je: ", $vysl, "\n");
}

 ?>
